telegram.ext.conversationhandler module
=======================================

.. automodule:: telegram.ext.conversationhandler
    :members:
    :undoc-members:
    :show-inheritance:
