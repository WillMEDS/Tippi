telegram.ext.typehandler module
===============================

.. automodule:: telegram.ext.typehandler
    :members:
    :undoc-members:
    :show-inheritance:
