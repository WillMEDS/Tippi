telegram.inlinequeryresultdocument module
=========================================

.. automodule:: telegram.inlinequeryresultdocument
    :members:
    :undoc-members:
    :show-inheritance:
