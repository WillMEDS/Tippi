telegram.ext.updater module
===========================

.. automodule:: telegram.ext.updater
    :members:
    :undoc-members:
    :show-inheritance:
