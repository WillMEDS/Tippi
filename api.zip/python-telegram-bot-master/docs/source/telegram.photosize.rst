telegram.photosize module
=========================

.. automodule:: telegram.photosize
    :members:
    :undoc-members:
    :show-inheritance:
