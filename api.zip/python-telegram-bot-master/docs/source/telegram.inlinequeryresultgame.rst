telegram.inlinequeryresultgame module
=====================================

.. automodule:: telegram.inlinequeryresultgame
    :members:
    :undoc-members:
    :show-inheritance:
