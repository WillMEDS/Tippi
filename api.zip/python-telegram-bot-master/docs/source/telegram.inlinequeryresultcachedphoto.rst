telegram.inlinequeryresultcachedphoto module
============================================

.. automodule:: telegram.inlinequeryresultcachedphoto
    :members:
    :undoc-members:
    :show-inheritance:
