telegram.file module
====================

.. automodule:: telegram.file
    :members:
    :undoc-members:
    :show-inheritance:
