telegram.user module
====================

.. automodule:: telegram.user
    :members:
    :undoc-members:
    :show-inheritance:
