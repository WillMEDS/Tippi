telegram.inputcontactmessagecontent module
==========================================

.. automodule:: telegram.inputcontactmessagecontent
    :members:
    :undoc-members:
    :show-inheritance:
