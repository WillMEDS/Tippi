telegram.replykeyboardmarkup module
===================================

.. automodule:: telegram.replykeyboardmarkup
    :members:
    :undoc-members:
    :show-inheritance:
