telegram.venue module
=====================

.. automodule:: telegram.venue
    :members:
    :undoc-members:
    :show-inheritance:
