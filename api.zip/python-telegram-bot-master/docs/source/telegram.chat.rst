telegram.chat module
=========================

.. automodule:: telegram.chat
    :members:
    :undoc-members:
    :show-inheritance:
