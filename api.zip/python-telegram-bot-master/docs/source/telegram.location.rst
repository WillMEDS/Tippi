telegram.location module
========================

.. automodule:: telegram.location
    :members:
    :undoc-members:
    :show-inheritance:
