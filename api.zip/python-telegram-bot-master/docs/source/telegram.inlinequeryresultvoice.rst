telegram.inlinequeryresultvoice module
======================================

.. automodule:: telegram.inlinequeryresultvoice
    :members:
    :undoc-members:
    :show-inheritance:
