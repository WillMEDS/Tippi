telegram.ext.callbackqueryhandler module
========================================

.. automodule:: telegram.ext.callbackqueryhandler
    :members:
    :undoc-members:
    :show-inheritance:
