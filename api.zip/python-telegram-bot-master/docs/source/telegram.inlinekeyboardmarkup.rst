telegram.inlinekeyboardmarkup module
====================================

.. automodule:: telegram.inlinekeyboardmarkup
    :members:
    :undoc-members:
    :show-inheritance:
