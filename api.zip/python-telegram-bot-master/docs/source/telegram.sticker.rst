telegram.sticker module
=======================

.. automodule:: telegram.sticker
    :members:
    :undoc-members:
    :show-inheritance:
