telegram.inlinequeryresultgif module
====================================

.. automodule:: telegram.inlinequeryresultgif
    :members:
    :undoc-members:
    :show-inheritance:
