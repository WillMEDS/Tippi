telegram.bot module
===================

.. automodule:: telegram.bot
    :members:
    :show-inheritance:
