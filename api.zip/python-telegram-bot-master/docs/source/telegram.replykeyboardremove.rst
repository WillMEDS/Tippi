telegram.replykeyboardremove module
===================================

.. automodule:: telegram.replykeyboardremove
    :members:
    :undoc-members:
    :show-inheritance:
