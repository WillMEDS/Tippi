telegram.inlinequeryresultmpeg4gif module
=========================================

.. automodule:: telegram.inlinequeryresultmpeg4gif
    :members:
    :undoc-members:
    :show-inheritance:
