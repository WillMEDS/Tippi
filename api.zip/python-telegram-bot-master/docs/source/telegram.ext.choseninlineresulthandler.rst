telegram.ext.choseninlineresulthandler module
=============================================

.. automodule:: telegram.ext.choseninlineresulthandler
    :members:
    :undoc-members:
    :show-inheritance:
