telegram.inlinequeryresultlocation module
=========================================

.. automodule:: telegram.inlinequeryresultlocation
    :members:
    :undoc-members:
    :show-inheritance:
