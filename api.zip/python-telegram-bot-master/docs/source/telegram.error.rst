telegram.error module
=====================

.. automodule:: telegram.error
    :members:
    :undoc-members:
    :show-inheritance:
