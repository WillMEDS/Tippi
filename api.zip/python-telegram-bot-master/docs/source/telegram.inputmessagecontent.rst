telegram.inputmessagecontent module
===================================

.. automodule:: telegram.inputmessagecontent
    :members:
    :undoc-members:
    :show-inheritance:
