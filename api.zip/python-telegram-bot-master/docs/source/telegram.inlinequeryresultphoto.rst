telegram.inlinequeryresultphoto module
======================================

.. automodule:: telegram.inlinequeryresultphoto
    :members:
    :undoc-members:
    :show-inheritance:
