telegram.inputlocationmessagecontent module
===========================================

.. automodule:: telegram.inputlocationmessagecontent
    :members:
    :undoc-members:
    :show-inheritance:
