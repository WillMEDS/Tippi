telegram.ext.commandhandler module
==================================

.. automodule:: telegram.ext.commandhandler
    :members:
    :undoc-members:
    :show-inheritance:
