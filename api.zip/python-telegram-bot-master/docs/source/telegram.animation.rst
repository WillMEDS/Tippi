telegram.animation module
=========================

.. automodule:: telegram.animation
    :members:
    :undoc-members:
    :show-inheritance:
