telegram.inlinequeryresultcachedvoice module
============================================

.. automodule:: telegram.inlinequeryresultcachedvoice
    :members:
    :undoc-members:
    :show-inheritance:
