telegram.messageentity module
=============================

.. automodule:: telegram.messageentity
    :members:
    :undoc-members:
    :show-inheritance:
